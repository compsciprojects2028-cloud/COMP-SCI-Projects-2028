#include "Arrow.hpp"
#include <cmath>

Arrow::Arrow(const sf::Texture& texture, float spawnTime, float xPos) 
    : sprite(texture)
{
    sprite.setPosition(sf::Vector2f(xPos, -100.f)); // spawn off-screen at top
    time = spawnTime;

    float hitLineY = 500.f;
    float leadTime = 2.f; // seconds it takes arrow to fall from spawn to hit line
    speed = (hitLineY - -100.f) / leadTime; // pixels per second

}

void Arrow::update(float songTime) {
    float timeUntilHit = time - songTime;
    float hitLineY = Arrow::hitLineY;

    sf::Vector2f pos = sprite.getPosition();
	pos.y = hitLineY - speed * timeUntilHit;
	sprite.setPosition(sf::Vector2f(std::round(pos.x), std::round(pos.y)));
}

float Arrow::getXPos() {
    return sprite.getPosition().x;
}

float Arrow::getTime() {
    return time;
}

void Arrow::draw(sf::RenderWindow& window) const {
    window.draw(sprite);
}  


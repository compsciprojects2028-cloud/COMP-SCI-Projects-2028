#include <iostream>
#include <vector>
#include "GameState.hpp"
#include "Textures.hpp"
#include "Note.hpp"
#include "Judgement.hpp"
#include "Chart.hpp"
#include "Arrow.hpp"
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <ctime>
#include <cstdlib>


void checkGameOverCondition(int missCount, GameState& gameState, bool& isEnd);
void checkForPassiveMisses(std::vector<Arrow>& arrows, float songTime, Judgement& judgement, sf::Text& judgementText, int& score, int& miss, GameState& gameState, bool& isEnd);

int main()
{
	// Create Window
	sf::RenderWindow window(sf::VideoMode({ 800, 600 }), "SFML Rhythm Game", sf::Style::Titlebar | sf::Style::Close);

	// Load Assets
	sf::Music music;

	if (!music.openFromFile("assets/audio/audio.ogg")) {
		std::cerr << "Failed to load music!" << std::endl;
		return -1;
	}


	sf::Clock frameClock;

	sf::Texture arrowTextures[4][2];

	for(int i = 0; i < 4; ++i) {
		for(int j = 0; j < 2; ++j) {
			if (!arrowTextures[i][j].loadFromFile(ARROW_PATHS[i][j])) {
				std::cerr << "Failed to load arrow texture: " << ARROW_PATHS[i][j] << std::endl;
				return -1;
			}
		}
	}

	sf::Font font;
	if (!font.openFromFile("assets/fonts/arial.ttf")) {
		std::cerr << "Failed to load font!" << std::endl;
		return -1;
	}

	sf::Text scoreText(font);
	sf::Text judgementText(font);

	scoreText.setCharacterSize(30);
	scoreText.setFillColor(sf::Color::White);
	scoreText.setPosition({ 20.f, 20.f });
	scoreText.setString("Score: 0");

	judgementText.setCharacterSize(32);
	judgementText.setFillColor(sf::Color::Yellow);
	judgementText.setPosition({ 300.f, 400.f });
	judgementText.setString("");

	// Classes

	GameState gameState = GameState::Menu;

	Chart chart;

	if (!chart.loadFromCsv("assets/charts/chart.csv")) {
		std::cerr << "Failed to load chart!" << std::endl;
		return -1;
	}

	Judgement judgement;
	
	// Vectors
	const std::vector<Note>& notes = chart.getNotes();

	std::vector<bool> spawned(notes.size(), false);

	std::vector<Arrow> arrows;

	// Other Important Variables
	float columnPositions[4] = { 150.f, 300.f, 450.f, 600.f }; // X positions 

	float hitLineY = 500.f;

	srand(static_cast<unsigned int>(time(0))); // Seed random number generator

	sf::Sprite receptors[4] = {
		sf::Sprite(arrowTextures[0][0]),
		sf::Sprite(arrowTextures[1][0]),
		sf::Sprite(arrowTextures[2][0]),
		sf::Sprite(arrowTextures[3][0]),
	};

	for (int i = 0; i < 4; ++i) {
		receptors[i].setPosition(sf::Vector2f(columnPositions[i], hitLineY));
	}

	float receptorFlashTimer[4] = { 0.f, 0.f, 0.f, 0.f };
	constexpr float FLASH_DURATION = 0.08f; // 80 ms

	sf::Keyboard::Key keys[4] = {
		sf::Keyboard::Key::Left,
		sf::Keyboard::Key::Down,
		sf::Keyboard::Key::Up,
		sf::Keyboard::Key::Right
	}; 

	constexpr float PERFECT = 0.030f; 
	constexpr float GREAT = 0.060f; 
	constexpr float GOOD = 0.090; 
	constexpr float OKAY = 0.120f; 

	int score = 0;
	int miss = 0;

	int pressedColumn = -1;
	float songLength = 30.464f; // Length of the song in seconds
	bool isEnd = false;


	// 3. Main Game Loop
	while(window.isOpen()) {
		// 3a. Event polling
		while (auto event = window.pollEvent()) {
			if (event->is<sf::Event::Closed>()) {
				window.close();
			}

			if(gameState == GameState::Menu) {
				if(auto keyEvent = event->getIf<sf::Event::KeyPressed>()) {
					if (keyEvent->code == sf::Keyboard::Key::Enter) {
						gameState = GameState::Playing;
						music.play();
						frameClock.restart();
					}
				}
			}

			if (auto keyEvent = event->getIf<sf::Event::KeyPressed>()) {
				for (int i = 0; i < 4; i++) {
					if (keyEvent->code == keys[i]) {
						pressedColumn = i;
						break;
					}
				}
			}
			
		}
		// 3b. Get current song time
		float songTime = music.getPlayingOffset().asSeconds();
		float deltaTime = frameClock.restart().asSeconds();

		checkForPassiveMisses(arrows, songTime, judgement, judgementText, score, miss, gameState, isEnd);

		// 3c. Update all active arrows' positions
		for (size_t i = 0; i < notes.size(); ++i) {
			float spawnLeadTime = 2.f; // seconds before hit time to spawn
			if(!spawned[i] && notes[i].time - songTime <= spawnLeadTime) {
				int randVariant = rand() % 2;
				sf::Texture& texture = arrowTextures[notes[i].column][randVariant];
				arrows.emplace_back(texture, notes[i].time, columnPositions[notes[i].column]);
				spawned[i] = true;
			}
		}
		

		// 3d. Check for input hits / assign Judgement
		for (Arrow& arrow : arrows) {
			arrow.update(songTime);
		}
		if (pressedColumn != -1) {
			float bestDelta = OKAY;
			auto bestArrow = arrows.end();

			for (auto it = arrows.begin(); it != arrows.end(); ++it) {
				if (it->getXPos() != columnPositions[pressedColumn]) {
					continue; // Skip arrows not in the pressed column
				}

				float delta = std::abs(it->getTime() - songTime);
				if (delta <= bestDelta) {
					bestDelta = delta;
					bestArrow = it;
				}
			}

			if (bestArrow != arrows.end()) {
				// Determine Judgement
				if (bestDelta <= PERFECT) {
					judgement = Judgement::Perfect;
					score += 4;
				}
				else if (bestDelta <= GREAT) {
					judgement = Judgement::Great;
					score += 3;
				}
				else if (bestDelta <= GOOD) {
					judgement = Judgement::Good;
					score += 2;
				}
				else if (bestDelta <= OKAY) {
					judgement = Judgement::Ok;
					score += 1;
				}
				// Flash receptor
				receptorFlashTimer[pressedColumn] = FLASH_DURATION;
				// Remove arrow
				arrows.erase(bestArrow);
			}
			else  {
				judgement = Judgement::Miss;
				score = 0;
				miss++;
			}

			// Update judgement text
			scoreText.setString("Score: " + std::to_string(score));

			switch (judgement) {
			case Judgement::Perfect:
				judgementText.setString("Perfect!");
				judgementText.setFillColor(sf::Color::Cyan);
				break;
			case Judgement::Great:
				judgementText.setString("Great!");
				judgementText.setFillColor(sf::Color::Green);
				break;
			case Judgement::Good:
				judgementText.setString("Good");
				judgementText.setFillColor(sf::Color::Yellow);
				break;
			case Judgement::Ok:
				judgementText.setString("Ok");
				judgementText.setFillColor(sf::Color(255, 165, 0));
				break;
			case Judgement::Miss:
				judgementText.setString("Miss");
				judgementText.setFillColor(sf::Color::Red);
				break;
			}
			pressedColumn = -1;
		}
					
		for (int i = 0; i < 4; ++i) {
			if (receptorFlashTimer[i] > 0.f) {
				receptorFlashTimer[i] -= deltaTime;
				if (receptorFlashTimer[i] < 0.f)
					receptorFlashTimer[i] = 0.f;
			}
		}
		if(gameState == GameState::Playing && miss > 2) {
			gameState = GameState::GameOver;
		}

		if (gameState == GameState::Playing && songTime >= songLength) {
			gameState = GameState::GameEnd;
			isEnd = true;
		}
		
		// 3e. Clear window 
		 window.clear(sf::Color::Black);

		 if (gameState == GameState::Menu) {
			 sf::Text titleText(font);
			 titleText.setFillColor(sf::Color::White);
			 titleText.setPosition({ 175.f, 225.f });
			 titleText.setCharacterSize(48);
			 titleText.setString("Press Enter to Start");
			 window.draw(titleText);
		 }

		 else if (gameState == GameState::Playing) {
			 // Continue with game rendering
			 for (int i = 0; i < 4; ++i) {
				 if (receptorFlashTimer[i] > 0.f) {
					 receptors[i].setColor(sf::Color::White);
					 receptors[i].setScale(sf::Vector2(1.05f, 1.05f));
				 }
				 else {
					 receptors[i].setColor(sf::Color(140, 140, 140, 255));
					 receptors[i].setScale(sf::Vector2f(1.0f, 1.0f));
				 }
				 window.draw(receptors[i]);
			 }
			 for (const Arrow& arrow : arrows) {
				 arrow.draw(window);
			 }

			 window.draw(scoreText);
			 window.draw(judgementText);
		 }
		 else if (gameState == GameState::GameOver) {
			 sf::Text gameoverText(font);
			 gameoverText.setFillColor(sf::Color::Red);
			 gameoverText.setPosition({ 250.f, 225.f });
			 gameoverText.setCharacterSize(48);
			 gameoverText.setString("You Failed!");
			 window.draw(gameoverText);
		 }
		 else if (gameState == GameState::GameEnd) {
			 sf::Text gameendText(font);
			 gameendText.setFillColor(sf::Color::Green);
			 gameendText.setPosition({ 175.f, 225.f });
			 gameendText.setCharacterSize(48);
			 gameendText.setString("Thank you for playing!");
			 window.draw(gameendText);
		 }

		// 3g. Display
		window.display();
	}
}

void checkGameOverCondition(int missCount, GameState& gameState, bool& isEnd) {
	if (missCount > 2 && gameState == GameState::Playing && !isEnd) {
		gameState = GameState::GameOver;
	}
}

void checkForPassiveMisses(std::vector<Arrow>& arrows, float songTime, Judgement& judgement, sf::Text& judgementText, int& score, int& miss, GameState& gameState, bool& isEnd) {
	constexpr float MISS_THRESHOLD = 0.125f; // 125 ms
	bool missedThisFrame = false;

	for(auto it = arrows.begin(); it != arrows.end();) {
		float delta = std::abs(it->getTime() - songTime);

		if(delta > MISS_THRESHOLD && it->getTime() < songTime) {
			// Handle the miss
			judgement = Judgement::Miss;
			miss++;
			score = 0;
			missedThisFrame = true;

			// Update display
			judgementText.setString("Miss");
			judgementText.setFillColor(sf::Color::Red);
			
			it = arrows.erase(it); // Remove missed arrow
		} else {
			++it;
		}
		if (missedThisFrame) {
			checkGameOverCondition(miss, gameState, isEnd);
		}
	}
}
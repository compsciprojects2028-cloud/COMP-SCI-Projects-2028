#include "Chart.hpp"
#include <vector>
#include <fstream>
#include <sstream>

bool Chart::loadFromCsv(const std::string& filename) {
	std::ifstream file(filename);
	if (!file.is_open()) {
		return false;
	}

	notes.clear();
	std::string line;
	std::getline(file, line); // Skip header

	while (std::getline(file, line)) {
		std::stringstream ss(line);
		std::string timeStr, columnStr;

		std::getline(ss, timeStr, ',');
		std::getline(ss, columnStr, ',');

		Note note;

		note.time = std::stof(timeStr);
		note.column = std::stoi(columnStr);	

		notes.push_back(note);
	}
	return true;
}

bool Chart::saveToCsv(const std::string& filename) const {
	std::ofstream file("chart.csv");

	if (!file.is_open()) {
		return false;
	}

	file << "time, column\n"; // header

	for (const auto& note : notes) {
		file << note.time << "," << note.column << "\n";
	}

	return true;
}

const std::vector<Note>& Chart::getNotes() const {
	return notes;
}
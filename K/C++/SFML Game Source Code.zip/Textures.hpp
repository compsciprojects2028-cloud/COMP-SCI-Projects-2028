#pragma once 
#include <string>

inline const std::string ARROW_PATHS[4][2] = {
	{"assets/textures/blue.png", "assets/textures/red.png"}, // Left
	{"assets/textures/navyblue.png", "assets/textures/yellow.png"}, // Down
	{"assets/textures/green.png", "assets/textures/purple.png"}, // Up
	{"assets/textures/cyan.png", "assets/textures/pink.png"} // Right
};
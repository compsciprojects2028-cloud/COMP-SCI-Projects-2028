#pragma once
#include <vector>
#include <string>
#include "Note.hpp"

class Chart {
public:
	bool loadFromCsv(const std::string& filename);
	bool saveToCsv(const std::string& filename) const;

	const std::vector<Note>& getNotes() const;

private:
	std::vector<Note> notes;
};
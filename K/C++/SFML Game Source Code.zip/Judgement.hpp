#pragma once

enum class Judgement
{
	Perfect,
	Great,
	Good,
	Ok,
	Miss,
};
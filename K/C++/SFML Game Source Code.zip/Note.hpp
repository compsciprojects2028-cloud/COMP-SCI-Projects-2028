#pragma once

struct Note {
	float time;
	int column; // 0 = Left, 1 = Down, 2 = Up, 3 = Right
};
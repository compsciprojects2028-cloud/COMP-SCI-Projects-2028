enum class GameState {
	Menu,
	Playing,
	GameOver,
	GameEnd
};
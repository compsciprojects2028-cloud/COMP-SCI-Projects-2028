#pragma once
#include <SFML/Graphics.hpp>

class Arrow {
public:
	Arrow(const sf::Texture& texture, float spawnTime, float xPos);

	void update(float songTime);
	void draw(sf::RenderWindow& window) const;
	float getXPos();
	float getTime();

private:
	sf::Sprite sprite;
	float time; // when the note should be hit
	float speed; // pixels per second
	float hitLineY = 500.f; // Y position of the hit line
};